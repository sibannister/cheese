﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Carousel;
using System.Collections;
using System.Windows.Media.Animation;

namespace CarouselWPFTestApp
{
    public partial class CustomiseWindow : Window
    {

        private CarouselControl carouselControl;
        private DataTemplate robotDataTemplate = 
            (Application.Current as App).Resources["robotDataTemplate"] as DataTemplate;
        private DataTemplate personDataTemplate =
            (Application.Current as App).Resources["personDataTemplate"] as DataTemplate;
        private Style blackPreviousButtonStyle =
            (Application.Current as App).Resources["BlackPreviousButtonStyle"] as Style;
        private Style blackNextButtonStyle =
            (Application.Current as App).Resources["BlackNextButtonStyle"] as Style;
        private PowerEase powerEaseIn;
        private PowerEase powerEaseOut;
        private BounceEase bounceEaseIn;
        private BounceEase bounceEaseOut;
        private SineEase sineEaseIn;
        private SineEase sineEaseOut;


        public CustomiseWindow()
        {
            InitializeComponent();
            powerEaseIn = new PowerEase() { Power = 6, EasingMode = EasingMode.EaseIn };
            powerEaseOut = new PowerEase() { Power = 6, EasingMode = EasingMode.EaseOut };
            bounceEaseIn = new BounceEase() { Bounces = 1, Bounciness = 4, EasingMode = EasingMode.EaseIn };
            bounceEaseOut = new BounceEase() { Bounces = 1, Bounciness = 4, EasingMode = EasingMode.EaseOut };
            sineEaseIn = new SineEase() { EasingMode = EasingMode.EaseIn };
            sineEaseOut = new SineEase() { EasingMode = EasingMode.EaseOut };
        }

        public CarouselControl CarouselControl
        {
            get { return carouselControl; }
            set
            {
                carouselControl = value;
                carouselControl.ItemsSource = GetRobotData();
                carouselControl.DataTemplateToUse = robotDataTemplate;
                MainWindow.CurrentDemoDataTemplateType = DemoDataTemplateType.Robot;
                slider.Minimum = carouselControl.MinNumberOfItemsOnPath;
                slider.Maximum = carouselControl.MaxNumberOfItemsOnPath;
                slider.Value = carouselControl.NumberOfItemsOnPath;
            }
        }


        private IEnumerable GetRobotData()
        {
            Random rand = new Random();
            List<RobotData> robotData = new List<RobotData>();

            for (int i = 0; i < 15; i++)
            {
                int idx = rand.Next(1, 9);
                robotData.Add(new RobotData(
                    string.Format("Robot{0}", idx),
                    string.Format("../Images/robot{0}.png", idx)));
            }

            return robotData;
        }

        private IEnumerable GetPersonData()
        {
            List<PersonData> personData = new List<PersonData>();
            personData.Add(new PersonData("Steve", "Soloman", "Mr", true));
            personData.Add(new PersonData("Ryan", "Worseley", "Mr", true));
            personData.Add(new PersonData("Sacha", "Barber", "Mr", true));
            personData.Add(new PersonData("Amy", "Amer", "Mrs", false));
            personData.Add(new PersonData("Samar", "Bou-Antoine", "Mrs", false));
            personData.Add(new PersonData("Fredrik", "Bornander", "Mr", true));
            personData.Add(new PersonData("Richard", "King", "Mr", true));
            personData.Add(new PersonData("Henry", "McKeon", "Mr", true));
            personData.Add(new PersonData("Debbie", "Doyle", "Mrs", false));
            personData.Add(new PersonData("Sarah", "Burns", "Mrs", false));
            personData.Add(new PersonData("Hank", "Dales", "Mr", true));
            personData.Add(new PersonData("Daniel", "Jones", "Mr", true));
            personData.Add(new PersonData("Lisa", "Dove", "Mrs", true));
            personData.Add(new PersonData("Rena", "Sams", "Mrs", false));
            personData.Add(new PersonData("Sarah", "Gray", "Mrs", false));
            
            return personData;
        }

        
        
        private void CmbPath_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cmbPath.SelectedItem != null && CarouselControl != null)
            {
                CarouselControl.PathType = (PathType)Enum.Parse(typeof(PathType),
                    ((ComboBoxItem)cmbPath.SelectedItem).Tag.ToString());
            }
        }


        private void CmbNavigationButtonLocation_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cmbNavigationButtonLocation.SelectedItem != null && CarouselControl != null)
            {
                CarouselControl.NavigationButtonPosition = (ButtonPosition)Enum.Parse(typeof(ButtonPosition),
                    ((ComboBoxItem)cmbNavigationButtonLocation.SelectedItem).Tag.ToString());
            }
        }


        

        private void CmbEasing_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cmbEasing.SelectedItem != null && CarouselControl != null)
            {
                String animationSelected = ((ComboBoxItem)cmbEasing.SelectedItem).Tag.ToString();

                switch (animationSelected)
                {
                    case "PowerEase":
                        CarouselControl.AnimationEaseIn = powerEaseIn;
                        CarouselControl.AnimationEaseOut = powerEaseOut;
                        break;
                    case "BounceEase":
                        CarouselControl.AnimationEaseIn = bounceEaseIn;
                        CarouselControl.AnimationEaseOut = bounceEaseOut;
                        break;
                    case "SineEase":
                        CarouselControl.AnimationEaseIn = sineEaseIn;
                        CarouselControl.AnimationEaseOut = sineEaseOut;
                        break;
                }
            }
        }

        private void ChangeButtonStyle_Click(object sender, RoutedEventArgs e)
        {
            CarouselControl.PreviousButtonStyle = blackPreviousButtonStyle;
            CarouselControl.NextButtonStyle = blackNextButtonStyle;
        }

        private void CmbDataTemplate_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cmbDataTemplate.SelectedItem != null && CarouselControl != null)
            {
                String templateSelected = ((ComboBoxItem)cmbDataTemplate.SelectedItem).Tag.ToString();

                switch (templateSelected)
                {
                    case "Robot":
                        carouselControl.ItemsSource = GetRobotData();
                        carouselControl.DataTemplateToUse = robotDataTemplate;
                        MainWindow.CurrentDemoDataTemplateType = DemoDataTemplateType.Robot;
                        break;
                    case "Person":
                        carouselControl.ItemsSource = GetPersonData();
                        carouselControl.DataTemplateToUse = personDataTemplate;
                        MainWindow.CurrentDemoDataTemplateType = DemoDataTemplateType.Person;
                        break;
                }
            }
            
            

        }

        private void Slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if(CarouselControl != null)
                CarouselControl.NumberOfItemsOnPath = (int)slider.Value;
        }

        
        

    }
}
