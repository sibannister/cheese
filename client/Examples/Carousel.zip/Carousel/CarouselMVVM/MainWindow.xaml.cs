﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CarouselMVVM
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        MainWindowViewModel vm = new MainWindowViewModel();
        public MainWindow()
        {
            this.DataContext = vm;
            InitializeComponent();
        }

        /// <summary>
        /// This should not be nessecary, but could not get wrapper to update Binding when
        /// SelectedItem changed...Tried lots of stuff, this is hack, but ran out of steam.
        /// </summary>
        private void CarouselControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count > 0)
            {
                lblSelectedItem.Content = e.AddedItems[0].ToString();
                vm.CurrentData = (string)e.AddedItems[0];
            }
        }
    }
}
