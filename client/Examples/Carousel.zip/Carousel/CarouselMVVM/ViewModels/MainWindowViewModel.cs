﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Windows.Data;
using System.Windows.Input;


namespace CarouselMVVM
{
    public class MainWindowViewModel : INPCBase
    {
        private List<String> data;
        private string currentData;
        private int currentPos = 0;

        public MainWindowViewModel()
        {
            data = new List<string>();
            for (int i = 0; i < 20; i++)
            {
                data.Add(String.Format("Item_{0}",i.ToString()));
            }



            //commands
            DecrementCommand = new SimpleCommand<Object, Object>(ExecuteDecrementCommand);
            IncrementCommand = new SimpleCommand<Object, Object>(ExecuteIncrementCommand);



        }


 

        private void ExecuteDecrementCommand(Object parameter)
        {
            if (currentPos > 0)
            {
                --currentPos;
                CurrentData = data[currentPos];
            }
        }


        private void ExecuteIncrementCommand(Object parameter)
        {
            if (currentPos < data.Count -1)
            {
                ++currentPos;
                CurrentData = data[currentPos];
            }
        }

        public ICommand DecrementCommand { get; private set; }
        public ICommand IncrementCommand { get; private set; }


        public List<String> Data
        {
            get { return data; }
        }


        public string CurrentData
        {
            get { return currentData; }
            set
            {
                if (currentData != value)
                {
                    currentData = value;
                    currentPos = data.IndexOf(currentData);
                    NotifyPropertyChanged("CurrentData");
                }
            }
        }
    }
}
